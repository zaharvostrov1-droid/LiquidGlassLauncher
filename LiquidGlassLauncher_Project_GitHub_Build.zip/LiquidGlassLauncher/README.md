# Liquid Glass Launcher

An independent Android launcher concept inspired by translucent liquid-glass UI. This is not an official Apple/iOS product.

## Prototype features
- Android Home/Launcher activity
- Installed-app grid and live search
- Open apps and long-press app actions
- Simple in-memory folders
- Glass-like translucent cards and dock
- Wallpaper background with blur on Android 12+ (API 31+)
- Basic fade transition when launching apps

## Build an APK using only an Android phone (GitHub Actions)

1. Download `LiquidGlassLauncher_Project.zip` to your phone and extract it with your file manager.
2. Open https://github.com in your browser and sign in.
3. Create a new **public** repository named `LiquidGlassLauncher` (public is simplest for this starter workflow).
4. Open the repository, choose **Add file > Upload files**.
5. Upload the *contents* of the extracted `LiquidGlassLauncher` folder, not the ZIP itself. Make sure `.github/workflows/android.yml` is included. If your phone's file picker hides `.github`, use the repository's web editor to create the workflow file at `.github/workflows/android.yml` using the file contents in this project.
6. Commit the files to the `main` branch.
7. Open the repository's **Actions** tab. Choose **Build Liquid Glass Launcher APK** from the workflow list.
8. Tap **Run workflow**, select `main`, and confirm.
9. Wait for the run to finish. Open the successful run and find **Artifacts** near the bottom.
10. Download `LiquidGlassLauncher-debug-apk`, extract the downloaded artifact ZIP, and locate `app-debug.apk`.
11. Open the APK and allow installation from your browser or file manager if Android asks. Only install APKs from your own repository/build.

If GitHub Actions is disabled for the repository, open **Settings > Actions > General** and allow actions.

## Important limitations
- This is a starter prototype, not a finished iOS replica.
- The workflow is provided but has not been run/verified in this environment.
- Wallpaper blur uses Android `RenderEffect` on API 31+; older Android versions show the wallpaper without this blur.
- Folder membership is currently in memory and resets when the launcher process is recreated.
- The welcome card is a visual placeholder, not a full Android AppWidgetHost implementation.
- Wallpaper-based adaptive color extraction and dynamic icon theming are not yet implemented; glass currently uses a neutral tint.
- Dock actions depend on apps installed on the device.
- Android retains control of the system lock screen, notification shade, and quick settings.

## Package
`com.liquidglass.launcher`
