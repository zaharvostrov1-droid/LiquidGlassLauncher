package com.liquidglass.launcher

import android.app.Activity
import android.app.WallpaperManager
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.RenderEffect
import android.graphics.Shader
import android.graphics.drawable.BitmapDrawable
import android.graphics.drawable.Drawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.view.inputmethod.InputMethodManager
import android.content.Context
import android.widget.*
import android.text.Editable
import android.text.TextWatcher
import kotlin.math.max

class MainActivity : Activity() {
    private lateinit var root: FrameLayout
    private lateinit var content: LinearLayout
    private lateinit var search: EditText
    private lateinit var appGrid: GridLayout
    private lateinit var allApps: List<AppEntry>
    private val folders = linkedMapOf<String, MutableList<AppEntry>>()
    private var accent = Color.rgb(224, 181, 255)

    data class AppEntry(val label: String, val packageName: String, val icon: Drawable)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.TRANSPARENT
        window.navigationBarColor = Color.argb(65, 15, 18, 32)
        if (Build.VERSION.SDK_INT >= 29) {
            window.setNavigationBarContrastEnforced(false)
            window.setStatusBarContrastEnforced(false)
        }
        buildUi()
        loadApps()
        renderApps("")
    }

    private fun buildUi() {
        root = FrameLayout(this)
        root.setBackgroundColor(Color.rgb(22, 24, 42))
        setWallpaperBackground()

        val shade = View(this).apply {
            setBackgroundColor(Color.argb(48, 12, 14, 28))
        }
        root.addView(shade, FrameLayout.LayoutParams(-1, -1))

        content = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(12), dp(20), dp(18))
        }
        root.addView(content, FrameLayout.LayoutParams(-1, -1))

        val top = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER_VERTICAL
        }
        val time = TextView(this).apply {
            text = java.text.SimpleDateFormat("HH:mm", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 34f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.create("sans-serif", android.graphics.Typeface.NORMAL)
            setShadowLayer(12f, 0f, 2f, Color.argb(110, 0, 0, 0))
        }
        top.addView(time, LinearLayout.LayoutParams(0, -2, 1f))
        val date = TextView(this).apply {
            text = java.text.SimpleDateFormat("EEE, d MMM", java.util.Locale.getDefault()).format(java.util.Date())
            textSize = 13f
            setTextColor(Color.argb(220, 255, 255, 255))
        }
        top.addView(date)
        content.addView(top)
        content.addView(space(20))

        val widget = glassCard(18, 16).apply {
            orientation = LinearLayout.VERTICAL
        }
        widget.addView(TextView(this).apply {
            text = "Good day ✨"
            textSize = 19f
            setTextColor(Color.WHITE)
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        })
        widget.addView(TextView(this).apply {
            text = "Your space, your mood"
            textSize = 13f
            setTextColor(Color.argb(220, 255, 255, 255))
            setPadding(0, dp(4), 0, 0)
        })
        content.addView(widget, LinearLayout.LayoutParams(-1, dp(82)))
        content.addView(space(16))

        search = EditText(this).apply {
            hint = "⌕   Search apps"
            textSize = 15f
            setSingleLine(true)
            setTextColor(Color.WHITE)
            setHintTextColor(Color.argb(190, 255, 255, 255))
            background = glassDrawable(100, 0.22f)
            setPadding(dp(18), 0, dp(18), 0)
            isFocusableInTouchMode = true
        }
        content.addView(search, LinearLayout.LayoutParams(-1, dp(48)))
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) { renderApps(s?.toString().orEmpty()) }
            override fun afterTextChanged(s: Editable?) {}
        })
        content.addView(space(14))

        val section = TextView(this).apply {
            text = "Applications"
            textSize = 14f
            setTextColor(Color.argb(225, 255, 255, 255))
            typeface = android.graphics.Typeface.DEFAULT_BOLD
        }
        content.addView(section)
        content.addView(space(8))

        val scroll = ScrollView(this).apply { clipToPadding = false }
        appGrid = GridLayout(this).apply {
            columnCount = 4
            useDefaultMargins = false
            alignmentMode = GridLayout.ALIGN_BOUNDS
        }
        scroll.addView(appGrid)
        content.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))

        val dock = LinearLayout(this).apply {
            orientation = LinearLayout.HORIZONTAL
            gravity = Gravity.CENTER
            background = glassDrawable(32, 0.27f)
            setPadding(dp(8), dp(8), dp(8), dp(8))
        }
        val dockItems = listOf("Phone" to "tel:", "Messages" to "sms:", "Camera" to "camera:", "Photos" to "photos:")
        dockItems.forEach { (label, action) ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                setOnClickListener { launchDockAction(action, label) }
            }
            val glyph = TextView(this).apply {
                text = when(label) { "Phone" -> "☎"; "Messages" -> "✉"; "Camera" -> "◉"; else -> "▧" }
                textSize = 25f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                background = glassDrawable(18, 0.32f)
            }
            tile.addView(glyph, LinearLayout.LayoutParams(dp(48), dp(48)))
            tile.addView(TextView(this).apply {
                text = label
                textSize = 9f
                gravity = Gravity.CENTER
                setTextColor(Color.WHITE)
                setPadding(0, dp(3), 0, 0)
            })
            dock.addView(tile, LinearLayout.LayoutParams(0, -2, 1f))
        }
        content.addView(space(8))
        content.addView(dock, LinearLayout.LayoutParams(-1, dp(78)))

        setContentView(root)
    }

    private fun loadApps() {
        val pm = packageManager
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        val entries = pm.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo.packageName
                if (pkg == packageName) null else try {
                    AppEntry(info.loadLabel(pm).toString(), pkg, info.loadIcon(pm))
                } catch (_: Exception) { null }
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase() }
        allApps = entries
    }

    private fun renderApps(query: String) {
        if (!::appGrid.isInitialized || !::allApps.isInitialized) return
        appGrid.removeAllViews()
        val filtered = allApps.filter { it.label.contains(query.trim(), true) }
        val width = (resources.displayMetrics.widthPixels - dp(40)) / 4
        filtered.forEach { app ->
            val tile = LinearLayout(this).apply {
                orientation = LinearLayout.VERTICAL
                gravity = Gravity.CENTER
                isClickable = true
                isFocusable = true
                setPadding(dp(2), dp(8), dp(2), dp(8))
                setOnClickListener { openApp(app) }
                setOnLongClickListener {
                    showAppActions(app)
                    true
                }
            }
            val icon = ImageView(this).apply {
                setImageDrawable(app.icon)
                scaleType = ImageView.ScaleType.FIT_CENTER
                background = glassDrawable(18, 0.10f)
                setPadding(dp(7), dp(7), dp(7), dp(7))
                elevation = dp(2).toFloat()
            }
            tile.addView(icon, LinearLayout.LayoutParams(dp(54), dp(54)))
            tile.addView(TextView(this).apply {
                text = app.label
                textSize = 10.5f
                gravity = Gravity.CENTER
                maxLines = 1
                ellipsize = android.text.TextUtils.TruncateAt.END
                setTextColor(Color.WHITE)
                setShadowLayer(5f, 0f, 1f, Color.BLACK)
                setPadding(0, dp(5), 0, 0)
            }, LinearLayout.LayoutParams(-1, -2))
            appGrid.addView(tile, GridLayout.LayoutParams().apply {
                width = width
                height = dp(92)
            })
        }
        if (filtered.isEmpty()) {
            appGrid.addView(TextView(this).apply {
                text = "No apps found"
                textSize = 14f
                setTextColor(Color.WHITE)
                setPadding(dp(10), dp(20), 0, 0)
            })
        }
    }

    private fun showAppActions(app: AppEntry) {
        val options = arrayOf("Open", "Add to folder", "App info")
        android.app.AlertDialog.Builder(this)
            .setTitle(app.label)
            .setItems(options) { _, which ->
                when (which) {
                    0 -> openApp(app)
                    1 -> showFolderDialog(app)
                    2 -> startActivity(Intent(android.provider.Settings.ACTION_APPLICATION_DETAILS_SETTINGS,
                        android.net.Uri.parse("package:${app.packageName}")))
                }
            }.show()
    }

    private fun showFolderDialog(app: AppEntry) {
        val names = (folders.keys + listOf("New folder…")).distinct().toTypedArray()
        android.app.AlertDialog.Builder(this).setTitle("Add to folder")
            .setItems(names) { _, index ->
                if (index == names.lastIndex && names[index] == "New folder…") {
                    val input = EditText(this).apply { hint = "Folder name" }
                    android.app.AlertDialog.Builder(this).setTitle("Create folder")
                        .setView(input).setPositiveButton("Create") { _, _ ->
                            val name = input.text.toString().trim().ifBlank { "My Folder" }
                            folders.getOrPut(name) { mutableListOf() }.add(app)
                            showFolder(name)
                        }.setNegativeButton("Cancel", null).show()
                } else {
                    folders.getOrPut(names[index]) { mutableListOf() }.add(app)
                    showFolder(names[index])
                }
            }.show()
    }

    private fun showFolder(name: String) {
        val items = folders[name]?.distinctBy { it.packageName }.orEmpty()
        android.app.AlertDialog.Builder(this).setTitle("▦  $name")
            .setItems(items.map { it.label }.toTypedArray()) { _, i -> openApp(items[i]) }
            .setPositiveButton("Done", null).show()
    }

    private fun openApp(app: AppEntry) {
        try {
            startActivity(packageManager.getLaunchIntentForPackage(app.packageName))
            overridePendingTransition(android.R.anim.fade_in, android.R.anim.fade_out)
        } catch (_: Exception) {
            Toast.makeText(this, "Can't open this app", Toast.LENGTH_SHORT).show()
        }
    }

    private fun launchDockAction(action: String, label: String) {
        val intent = when (action) {
            "tel:" -> Intent(Intent.ACTION_DIAL)
            "sms:" -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_MESSAGING)
            "camera:" -> Intent("android.media.action.IMAGE_CAPTURE")
            else -> Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_APP_GALLERY)
        }
        try { startActivity(intent) } catch (_: Exception) {
            Toast.makeText(this, "$label isn't available", Toast.LENGTH_SHORT).show()
        }
    }

    private fun setWallpaperBackground() {
        try {
            val wallpaper = WallpaperManager.getInstance(this).drawable
            if (wallpaper != null) {
                val image = ImageView(this).apply {
                    setImageDrawable(wallpaper)
                    scaleType = ImageView.ScaleType.CENTER_CROP
                    if (Build.VERSION.SDK_INT >= 31) {
                        setRenderEffect(RenderEffect.createBlurEffect(18f, 18f, Shader.TileMode.CLAMP))
                    }
                }
                root.addView(image, 0, FrameLayout.LayoutParams(-1, -1))
                return
            }
        } catch (_: Exception) {}
        root.background = android.graphics.drawable.GradientDrawable(
            android.graphics.drawable.GradientDrawable.Orientation.TL_BR,
            intArrayOf(Color.rgb(75, 49, 103), Color.rgb(28, 42, 76), Color.rgb(13, 17, 31))
        )
    }

    private fun glassCard(horizontal: Int, vertical: Int): LinearLayout =
        LinearLayout(this).apply {
            background = glassDrawable(24, 0.23f)
            setPadding(dp(horizontal), dp(vertical), dp(horizontal), dp(vertical))
            elevation = dp(4).toFloat()
        }

    private fun glassDrawable(radius: Int, alpha: Float): android.graphics.drawable.GradientDrawable {
        val bg = android.graphics.drawable.GradientDrawable()
        bg.cornerRadius = dp(radius).toFloat()
        bg.setColor(Color.argb((alpha * 255).toInt(), 255, 255, 255))
        bg.setStroke(dp(1), Color.argb(100, 255, 255, 255))
        return bg
    }

    private fun space(height: Int): View = View(this).apply {
        layoutParams = LinearLayout.LayoutParams(1, dp(height))
    }

    private fun dp(value: Int): Int = (value * resources.displayMetrics.density).toInt()
}
